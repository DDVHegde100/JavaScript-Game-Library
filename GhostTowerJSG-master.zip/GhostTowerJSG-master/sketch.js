var towerImage, tower;
var doorImage, door, doorGroup;
var climberImage, climber, climberGroup;
var ghost, ghostImage;
var gameState="play";
var invisibleGround, invisibleGroup;
function preload(){
  towerImage=loadImage("tower.png");
  doorImage=loadImage("door.png");
  climberImage=loadImage("climber.png");
  ghostImage=loadImage("ghost-standing.png");
}


function setup(){
  createCanvas(600, 600);
  tower=createSprite(300, 300, 20, 20);
  tower.addImage("image" ,towerImage);
  tower.velocityY=1;
  doorGroup=new Group();
  climberGroup=new Group();
  ghost=createSprite(300,200,20,20);
  ghost.addImage("Images6", ghostImage);
  ghost.scale=0.3;
  invisibleGroup= new Group();
}
function draw(){
  background(0);
  if(gameState==="play"){
  if(tower.y>400){
    tower.y=300;
  }
  doorSpawn();
  if(keyDown("space")){
    ghost.velocityY=-5; 
  }
  if(keyDown("left")){
    ghost.x=ghost.x-3;
  }
  if(keyDown("right")){
    ghost.x=ghost.x+3; 
  }
  ghost.velocityY=ghost.velocityY+0.8;
  if(climberGroup.isTouching(ghost)){
    ghost.velocityY=0;
  }
    if(invisibleGroup.isTouching(ghost)||ghost.y>600){
      ghost.destroy();
      gameState="end";
       }
  drawSprites();
  }
  if(gameState==="end"){
    fill("yellow");
    textSize(30);
    text("Game Over", 230, 250);
    
  }
}
function doorSpawn(){
  if(frameCount%240===0){
    door=createSprite(200,-50, 20, 20);
    climber=createSprite(200,10,20,2);
    invisibleGround=createSprite(200,15,20,2);
    invisibleGround.width=climber.width;
    door.addImage("images", doorImage);
    climber.addImage("images2", climberImage);
    door.velocityY=1;
    climber.velocityY=1;
    invisibleGround.velocityY=1;
    door.lifetime=600;
    climber.lifetime=600;
    doorGroup.add(door);
    climberGroup.add(climber);
    invisibleGroup.add(invisibleGround);
    door.x=Math.round(random(100,400));
    climber.x=door.x;
    ghost.depth=door.depth;
    invisibleGround.x=door.x;
    ghost.depth=ghost.depth+1;
  }
    
}