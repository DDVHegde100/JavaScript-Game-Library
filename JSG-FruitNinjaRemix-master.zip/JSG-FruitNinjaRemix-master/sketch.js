var Sword;
var sword;
var PLAY=1;
var END=0;
var gameState=1;
var fruitGroup, score;
var fruit;
var F1, F2, F3, F4;
var rand;
var monster, Monster;
var enemyGroup;
var gameOver;
var score;

function preload(){
 Sword=loadImage("sword.png");
 F1=loadImage("fruit1.png");
 F2=loadImage("fruit2.png");
  F3=loadImage("fruit3.png");
  F4=loadImage("fruit4.png");
  Monster=loadImage("alien1.png");
  gameOver=loadImage("gameover.png");
}
function setup(){
 sword=createSprite(40, 200, 20, 20);
 sword.addImage(Sword);
 sword.scale=0.7;
 fruitGroup=new Group();
 enemyGroup=new Group();
  score=0;
}

function draw(){
 background("white");
 drawSprites();
 text("score: "+score, 330,30);
if(gameState===PLAY){
  sword.x=World.mouseX;
  sword.y=World.mouseY;
  if(fruitGroup.isTouching(sword)){
    fruitGroup.destroyEach();
    
    score=score+2;
     }
  if(enemyGroup.isTouching(sword)){
      gameState=END;
    }
  fruits();
  Enemy();
}
  if(gameState===END){
    sword.addImage(gameOver);
    sword.x=200;
    sword.y=200;
  }

}
function fruits(){
  if(World.frameCount%80===0){
  fruit=createSprite(400, 200, 20, 20);
  fruit.scale=0.2;
  rand=Math.round(random(1,4));
  if (rand==1){
    fruit.addImage(F1);
  }
    if (rand==2){
    fruit.addImage(F2);
  }
    if (rand==3){
    fruit.addImage(F3);
  }
    if (rand==4){
    fruit.addImage(F4);
  }
    fruit.y=Math.round(random(50,340));
    fruit.velocityX=-7;
    fruit.setLifetime=100;
    fruitGroup.add(fruit);
      
     }
  if(score>4){
    fruit.velocityX=fruit.velocityX-3;
  }
   if(score>10){
    fruit.velocityX=fruit.velocityX-3;
  }
}
function Enemy(){
  if(World.frameCount%200===0){
    monster=createSprite(400,200,20,20);
    monster.addAnimation("moving", Monster);
    monster.y=Math.round(random(100,300));
    monster.velocityX=-8;
    monster.setLifetime=50;
    enemyGroup.add(monster);
  }
}
