# T-Rex-Game
Offline Chrome Dino Game
