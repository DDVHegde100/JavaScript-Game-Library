
var world,engine;
var player,sword;
var enemy,sun;
var backgroundImg;
var ground;
var playerImg;
var cloud, cloudImg;
var obstacle, obstacleImg;
var platform;
var invisibleGround;
var riverImg, river;
function preload(){
backgroundImg=loadImage("Forest.jpg");
playerImg=loadImage("Imported piskel (3).gif");
cloudImg=loadImage("580b585b2edbce24c47b263e.png");
obstacleImg=loadImage("Imported piskel (2).gif");
  riverImg=loadImage("Intro_Image.gif");
}
function setup(){
createCanvas(3000,800);
player=createSprite(300,400,80,80);
  player.addImage("player", playerImg);
ground=createSprite(1500,650,3000,20);
  platform=createSprite(300, 550, 80, 10);
river=createSprite(1500,700,3000,20);
  river.addImage("river", riverImg)
}
function draw(){
background(backgroundImg);
if(keyDown("space")){
    player.velocityY=-8;
}
     if (river.x<0){
       river.x=river.width/2;
     }
      
  platform.lifetime=10;
  player.velocityY=player.velocityY+1;
  river.velocityX=-6;
  spawnCloud();
  spawnObstacles();
  player.collide(platform);
  player.setCollider("rectangle", 0,0,400,player.height);
  drawSprites();
  
  if(keyDown("A")){
    player.x=player.x-3;
  }
  if(keyDown("D")){
    player.x=player.x+3;
  }

}
function spawnCloud(){
  if (frameCount % 60 === 0) {
     cloud = createSprite(2500,450,40,10);
    cloud.y = Math.round(random(150,350));
    cloud.addImage("clouds",cloudImg);
    cloud.scale = 0.1;
    cloud.velocityX = -6;
    
     //assign lifetime to the variable
    cloud.lifetime = 500;
    
    
    //adding cloud to the group
   //cloudsGroup.add(cloud);
    }
}
function spawnObstacles(){
 if (frameCount % 60 === 0){
   var obstacle = createSprite(1500,610,10,40);
   invisibleGround=createSprite(1500,580,68,10);
   obstacle.x=invisibleGround.x;
   obstacle.addImage("obstacle", obstacleImg);
   obstacle.velocityX = -6;
   invisibleGround.velocityX=-6;
     //player.collide(obstacle);
    //obstacle.x = Math.round(random(50,100));
    //generate random obstacles
    //assign scale and lifetime to the obstacle           
    obstacle.scale = 0.5;
    obstacle.lifetime = 500;
   
   //add each obstacle to the group
    //obstaclesGroup.add(obstacle);
 }
}
