//create sprite
var ball = createSprite(200,200,25,25);
var ball2 = createSprite(200, 200, 25, 25);
var ball3 = createSprite(200, 200, 25, 25);
var ball4 = createSprite(200, 200, 25, 25);
var ball5 = createSprite(200, 200, 15, 15);
var ball6 = createSprite(200, 200, 15, 15);
var ball7 = createSprite(200, 200, 15, 15);
var ball8 = createSprite(200, 200, 15, 15);
//Ball Velocity
ball.velocityX = -5;
ball.velocityY = -5;
ball2.velocityX = -5;
ball2.velocityY = 5;
ball3.velocityX = 5;
ball3.velocityY = -5;
ball4.velocityX = 5;
ball4.velocityY = 5;
ball5.velocityX = -4;
ball5.velocityY = -4;
ball6.velocityX = -4;
ball6.velocityY = 4;
ball7.velocityX = 4;
ball7.velocityY = -4;
ball8.velocityX = 4;
ball8.velocityY = 4;
//Ball color
ball.shapeColor = "red";
ball2.shapeColor = "orange";
ball3.shapeColor = "yellow";
ball4.shapeColor = "green";
ball5.shapeColor = "blue";
ball6.shapeColor = "purple";
ball7.shapeColor = "pink";
ball8.shapeColor = "indigo";
//Displaying Balls
function draw() {
  //Creating Background
  background("white");
  
  //Making Edges
  createEdgeSprites();
  //Making Balls bounce off Edges
  ball.bounceOff(edges);
  ball2.bounceOff(edges);
  ball3.bounceOff(edges);
  ball4.bounceOff(edges);
  ball5.bounceOff(edges);
  ball6.bounceOff(edges);
  ball7.bounceOff(edges);
  ball8.bounceOff(edges);
  //Drawing Sprites
  drawSprites();
}
