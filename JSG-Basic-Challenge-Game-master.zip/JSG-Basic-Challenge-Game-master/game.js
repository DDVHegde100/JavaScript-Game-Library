var ball = createSprite(200,200,10,10);
var wall = createSprite(400, 400, 10, 490);
var wall2 = createSprite(350, 350, 10, 400);
var wall3 = createSprite(346, 77, 400, 10);
wall.shapeColor = "yellow";
wall2.shapeColor = "lightblue";
wall3.shapeColor = "green";
ball.shapeColor = "orange";
wall.shapeColor

function draw() {
  background("white");
  ball.velocityY = 0;
  ball.velocityX = 0;
  createEdgeSprites();
  ball.bounceOff(edges);
  
  if(keyDown(UP_ARROW)) {
    ball.velocityX = 2;
    
    ball.velocityY = 0;
  }
  if (keyDown("DOWN_ARROW")) {
    ball.velocityX = -2;
    ball.velocityY = 0;
  }
  if (keyDown("LEFT_ARROW")) {
    ball.velocityX = 0;
    ball.velocityY = 2;
  }
  if (keyDown("RIGHT_ARROW")) {
    ball.velocityX = 0;
    ball.velocityY = -2;
  }
  if (ball.isTouching(wall)||ball.isTouching(wall2)||ball.isTouching(wall3)) {
    ball.x = 200;
    ball.y = 200;
  }
  strokeWeight(5);
  stroke("black");
  fill("red");
  textSize(40);
  text("Game", 0, 400);
  
  drawSprites();
}
wall.shapeColor
wall.shapeColor
